# GMI Foundation website (GitHub Pages starter)

## Files
- `index.html`: responsive storefront, demo product list, cart, WhatsApp order handoff, demo login/signup and demo admin product editor.

## Publish on GitHub Pages
1. GitHub par sign in karein aur **New repository** banayein, naam `gmi-foundation` rakhein.
2. Repository ko Public rakhna GitHub Pages ke free plan ke liye sabse seedha option hai.
3. `Add file` → `Upload files` se `index.html` upload karein, phir **Commit changes**.
4. Repository → **Settings** → **Pages** → **Build and deployment** mein `Deploy from a branch` select karein.
5. Branch `main`, folder `/(root)` choose karke **Save** karein.
6. Publish hone ke baad Pages screen par jo URL diya ho use kholein. URL kuch is format ka hoga: `https://YOUR-USERNAME.github.io/gmi-foundation/`.

## WhatsApp number set karna
`index.html` mein ye line dhoondhein:
`const WHATSAPP_NUMBER="91XXXXXXXXXX";`
Isse apne business WhatsApp number se replace karein, country code ke saath aur `+`, spaces ya dashes ke bina. Example format: `919876543210`.

## Important production limitations
- Login/signup currently demo-only. Static GitHub Pages files cannot safely store user accounts or admin secrets. Configure Firebase Authentication + Firestore Security Rules for real accounts and data.
- Admin PIN `2468` is only a front-end demo gate, not security. Anyone can inspect/edit the page or browser storage. Do not use it for real administration.
- Payment selector only sends a payment preference in the WhatsApp order message. It does not collect money or verify UPI payments. For verified online payments, integrate a payment gateway and server-side/webhook verification; do not put secret keys in this HTML.
- Product changes made in the demo admin panel are stored only in the current browser's localStorage and are not shared with customers on other devices.
- Replace sample products/prices with real inventory before launch. Confirm order, shipping, return and privacy policies before accepting real customers.
